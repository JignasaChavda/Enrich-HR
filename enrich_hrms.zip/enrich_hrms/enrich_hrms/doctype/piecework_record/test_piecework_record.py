# Copyright (c) 2025, jignasha@sanskartechnolab.com and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestPieceworkRecord(FrappeTestCase):
	pass
