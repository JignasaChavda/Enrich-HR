# Copyright (c) 2025, jignasha@sanskartechnolab.com and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document


class PieceworkDetails(Document):
	pass
